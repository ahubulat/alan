# tahu
File SC bukan Google shell
sayaHalloguys
