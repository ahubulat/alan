{
    "ownerNumber": "6285643774316",
    "ownerName": "Tahu Botz",
    "limitCount": 30,
    "gamewaktu": 60,
    "botName": "Tahu Botz",
    "pathImg": "./media/Itsuki.jpg",
    "apikey": "apikey is here",
    "fake": "ALAN BOTZ VERIFIED",
    "sesidInsta": "default",
    "sessionName": "aqulzz",
    "txtDonasi": "GOPAY : 085718366706\nSaweeria :https://saweria.co/alanbotz\nPulsa : 085718366706",
    "gcount": {
        "prem": 40,
        "user": 20
    },
    "emote":{
        "free": "◽",
        "owner": "◾",
        "limit": "🔸",
        "glimit": "🔹",
        "prem": "💰"
    }
}
